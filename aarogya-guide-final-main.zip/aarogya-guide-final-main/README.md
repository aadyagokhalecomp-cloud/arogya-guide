# Aarogya Guide Final

Build a polished, responsive web application called “Aushadhi Saathi” for a Smart India Hackathon project.

1. PROJECT PURPOSE

Aushadhi Saathi is a simple multilingual medication assistant that helps patients and caregivers understand handwritten medical prescriptions.

The core workflow must be:

Prescription Image → OCR → Medicine Extraction → Dosage & Frequency Extraction → Timing Calculation → Simple Medication Timeline → Language Translation

The application should be designed for elderly users, patients with limited health literacy, and caregivers.

Keep the application focused and easy to demonstrate. Do NOT add unnecessary features such as authentication, payments, pharmacy ordering, doctor dashboards, social features, chatbot, or complex analytics.

2. TECHNOLOGY

Use a modern web stack suitable for Lovable:

React

TypeScript

Vite

Tailwind CSS

shadcn/ui components

Lucide icons

Supabase only if needed for storing demo data

OCR/API integration should be structured so an OCR provider can be connected easily.

Use environment variables for API keys.

Never expose API keys in frontend code.

The UI must work well on both desktop and mobile.

3. MAIN LANGUAGE SUPPORT

The application must support exactly these 3 languages:

English

हिंदी (Hindi)

मराठी (Marathi)

Add a language selector in the top navigation:

English | हिंदी | मराठी

When the language is changed, all user-facing interface text should change accordingly.

Medicine names should normally remain in their recognized medical/brand form, while instructions such as dosage, frequency, timing, duration and food instructions should be translated.

Example:

English:
“Take 1 tablet twice daily after food.”

Hindi:
“भोजन के बाद दिन में 2 बार 1 गोली लें।”

Marathi:
“जेवणानंतर दिवसातून 2 वेळा 1 गोळी घ्या।”

4. LANDING PAGE

Create a clean healthcare-focused landing page.

Header:

Aushadhi Saathi

Subtitle:

“Your Prescription. Simplified.”

Supporting text:

“Scan your handwritten prescription and understand your medicines, dosage and timings in English, Hindi or Marathi.”

Primary CTA:

Scan Prescription

Secondary CTA:

How It Works

Use a warm, trustworthy healthcare visual style.

Use:

clean white/light background

soft green/blue healthcare accents

rounded cards

accessible typography

large buttons

clear icons

minimal animations

Do not make the interface look overly corporate or complicated.

5. HOW IT WORKS SECTION

Show 3 simple steps:

Step 1 — Scan

Upload or capture a photo of the handwritten prescription.

Step 2 — Understand

OCR identifies medicine names, dosage, frequency, duration and instructions.

Step 3 — Follow

Aushadhi Saathi converts the prescription into an easy medication schedule.

Use icons for each step.

6. PRESCRIPTION SCANNING PAGE

Create a dedicated Scan Prescription page.

The user should be able to:

Upload an image from device

Drag and drop an image

Use camera capture where supported

See a preview of the prescription

Remove/change the image

Click “Analyze Prescription”

Supported image formats:

JPG

JPEG

PNG

Show a short privacy message:

“Your prescription is used only to extract medication information for this session.”

After clicking Analyze, show a loading state:

Scanning prescription...

Then:

Reading handwritten medicines...

Then:

Preparing your medication schedule...

Use a progress indicator.

7. OCR EXTRACTION

Implement the OCR workflow so the uploaded prescription image is processed and text is extracted.

The extracted OCR text should NOT immediately be shown as the final answer.

Instead, parse the OCR result into structured medicine information.

The system should attempt to identify:

Medicine name

Strength

Dosage

Frequency

Timing

Duration

Food instruction

Special instruction if clearly present

For example, if OCR detects:

“Paracetamol 500 mg – 1 tab BD after food – 5 days”

Convert it into:

Medicine: Paracetamol
Strength: 500 mg
Dosage: 1 tablet
Frequency: 2 times a day
Timing: Morning and Evening
Food: After food
Duration: 5 days

8. DOSAGE AND FREQUENCY LOGIC

This is VERY IMPORTANT.

The application must display both dosage AND frequency AND actual suggested timings.

Recognize common prescription abbreviations where possible:

OD = Once daily

BD / BID = Twice daily

TDS / TID = Three times daily

QID = Four times daily

HS = At bedtime

SOS / PRN = As needed

AC = Before food

PC = After food

STAT = Immediately / single dose

Convert them into understandable language.

Examples:

OD

Dosage:
1 tablet

Frequency:
Once daily

Suggested timing:
Morning — 8:00 AM

BD / BID

Dosage:
1 tablet

Frequency:
Twice daily

Suggested timings:
Morning — 8:00 AM
Evening — 8:00 PM

TDS / TID

Dosage:
1 tablet

Frequency:
Three times daily

Suggested timings:
Morning — 8:00 AM
Afternoon — 2:00 PM
Night — 8:00 PM

QID

Dosage:
1 tablet

Frequency:
Four times daily

Suggested timings:
Morning — 8:00 AM
Afternoon — 12:00 PM
Evening — 4:00 PM
Night — 8:00 PM

IMPORTANT:
These timings are only a user-friendly representation of the prescribed frequency. Do NOT claim that these are medically prescribed times unless the prescription explicitly specifies the times.

Display a small note:

“Suggested timings are generated from the prescribed frequency. Follow the doctor's instructions if specific timings are written on the prescription.”

9. MEDICATION TIMELINE

After processing, display a beautiful medication timeline.

Create sections:

🌅 Morning

8:00 AM

Medicine cards underneath.

Example:

Paracetamol 500 mg

💊 1 tablet

🔄 Twice daily

🍽️ After food

📅 5 days

☀️ Afternoon

2:00 PM

Medicine cards.

🌙 Evening

8:00 PM

Medicine cards.

If bedtime medication exists:

🌙 Bedtime

10:00 PM

Medicine cards.

Make the timeline visually obvious and extremely easy to understand.

10. MEDICINE CARD

Every medicine should have a card containing:

Medicine Name

Strength
Example: 500 mg

Dosage
Example: 1 tablet

Frequency
Example: Twice daily

Timing
Example: Morning 8:00 AM + Evening 8:00 PM

Food instruction
Example: After food

Duration
Example: 5 days

Use icons for:

medicine

clock

frequency

food

calendar

The most important information should be visually prominent:

WHAT → HOW MUCH → HOW OFTEN → WHEN → HOW LONG

11. PRESCRIPTION REVIEW / VERIFICATION

Before showing the final medication timeline, provide a simple verification section.

Title:

“Please verify your prescription details”

Show the extracted information in editable fields.

Example:

Medicine:
[Paracetamol]

Strength:
[500 mg]

Dosage:
[1 tablet]

Frequency:
[Twice daily]

Timing:
[Morning 8:00 AM, Evening 8:00 PM]

Food:
[After food]

Duration:
[5 days]

Buttons:

Confirm & Create Schedule

Edit Details

This is important because handwritten prescription OCR can make mistakes.

12. LOW-CONFIDENCE OCR

If OCR is uncertain about a medicine name or instruction, clearly mark it.

Example:

⚠️ Please verify

“Unable to confidently read this medicine name.”

Do NOT silently invent or guess medical information.

For uncertain fields, show:

Needs verification

and allow the user to edit the field.

13. SAFETY NOTICE

Add a small but clearly visible disclaimer:

“ Aushadhi Saathi helps simplify prescription information. It does not diagnose medical conditions or replace advice from a doctor or pharmacist. Always verify extracted information before taking medicine.”

Do not provide medical recommendations or change prescribed dosage.

The application must only structure and simplify what is present in the prescription.

14. DEMO MODE / SAMPLE PRESCRIPTION

Because this is an SIH prototype, include a “Try Demo Prescription” button.

When clicked, load a predefined sample prescription and demonstrate the complete workflow without requiring a real OCR API.

Sample structured prescription:

Medicine 1:
Paracetamol 500 mg
Dosage: 1 tablet
Frequency: BD / Twice daily
Timing: Morning 8:00 AM and Evening 8:00 PM
Food: After food
Duration: 5 days

Medicine 2:
Cetirizine 10 mg
Dosage: 1 tablet
Frequency: OD / Once daily
Timing: Night 10:00 PM
Food: After food
Duration: 5 days

Medicine 3:
Vitamin D3
Dosage: 1 capsule
Frequency: Once weekly
Timing: Sunday after breakfast
Duration: 4 weeks

Label this clearly as:

Demo Prescription

This allows the SIH judges to see the complete application even if the OCR/API is unavailable during the presentation.

15. RESULTS PAGE

After verification, show:

“Your Medication Schedule”

At the top:

Good morning! Here is your medication plan.

Then show:

Today

and the medication timeline.

Include a simple summary:

3 Medicines
2 Morning doses
1 Evening dose
1 Night dose

Do not add complicated health analytics.

16. LANGUAGE TRANSLATION OF RESULTS

When Hindi is selected, translate the instructions.

Example:

English:

Paracetamol 500 mg
1 tablet
Twice daily
Morning 8:00 AM
Evening 8:00 PM
After food
5 days

Hindi:

पैरासिटामोल 500 mg
1 गोली
दिन में 2 बार
सुबह 8:00 बजे
शाम 8:00 बजे
भोजन के बाद
5 दिन

Marathi:

पॅरासिटामॉल 500 mg
1 गोळी
दिवसातून 2 वेळा
सकाळी 8:00 वाजता
संध्याकाळी 8:00 वाजता
जेवणानंतर
5 दिवस

Use proper Unicode fonts and ensure Hindi/Marathi text renders correctly.

17. VOICE — KEEP IT OPTIONAL AND SIMPLE

Do NOT build a complex voice assistant.

Only add a simple 🔊 Read Aloud button.

When clicked, read the currently displayed medication instructions using browser text-to-speech if available.

Example:

“Paracetamol 500 milligrams. Take one tablet twice daily, after food. Morning at 8 AM and evening at 8 PM.”

When Hindi is selected, use Hindi speech if the browser supports it.

When Marathi is selected, use Marathi speech if supported.

If browser speech support is unavailable, simply disable the button gracefully.

18. RESPONSIVE DESIGN

The website must work perfectly on:

Desktop

Laptop

Tablet

Mobile

For mobile:

Use large buttons.

Make medicine cards stacked vertically.

Keep the medication timeline easy to scroll.

The scan/upload button should be highly visible.

19. NAVIGATION

Keep navigation minimal.

Header:

Aushadhi Saathi

Home

Scan Prescription

Medication Schedule

Right side:

Language selector:
English | हिंदी | मराठी

Do not add unnecessary navigation items.

20. VISUAL DESIGN

Overall visual identity:

Simple + Trustworthy + Accessible + Indian Healthcare

Use:

soft healthcare colors

rounded cards

subtle shadows

clean spacing

large readable typography

clear icons

accessible contrast

Create a professional SIH-level prototype, not a generic template.

Use subtle animations only where useful:

upload transition

OCR processing

timeline appearance

language switching

Avoid excessive animation.

21. ERROR HANDLING

Handle:

No image uploaded

Unsupported file

OCR failure

Poor image quality

Unreadable handwriting

Missing medicine information

Missing dosage/frequency

API failure

For OCR failure show:

“ We couldn't clearly read this prescription. Please upload a clearer image or verify the extracted details manually.”

Never fabricate medicine names, dosage or frequency.

22. IMPORTANT DATA MODEL

Represent each medicine internally approximately as:

{
medicineName,
strength,
dosage,
dosageUnit,
frequency,
frequencyCount,
suggestedTimings,
foodInstruction,
duration,
specialInstruction,
confidence
}

Example:

{
medicineName: "Paracetamol",
strength: "500 mg",
dosage: "1",
dosageUnit: "tablet",
frequency: "Twice daily",
frequencyCount: 2,
suggestedTimings: ["08:00", "20:00"],
foodInstruction: "After food",
duration: "5 days",
specialInstruction: "",
confidence: 0.95
}

23. IMPORTANT UX PRINCIPLE

The application should always answer these five questions immediately:

1. WHAT?

Which medicine?

2. HOW MUCH?

What dosage?

3. HOW OFTEN?

What frequency?

4. WHEN?

What time should it be taken?

5. HOW LONG?

For how many days/weeks?

Make these the central design principle of the medication schedule.

24. DO NOT BUILD THESE FEATURES

To save development time and keep the SIH prototype focused, DO NOT implement:

User authentication

Payment

Pharmacy ordering

Doctor appointment booking

Doctor dashboard

Chatbot

Disease diagnosis

Drug interaction engine

Complex patient analytics

Wearable integration

GPS

Social login

Community forum

Prescription history database

Complex notification backend

The core product must remain:

SCAN → EXTRACT → VERIFY → SCHEDULE → TRANSLATE

25. FINAL USER FLOW

Implement this exact flow:

Landing Page
↓
Click “Scan Prescription”
↓
Upload/Capture Prescription
↓
Preview Image
↓
Click “Analyze Prescription”
↓
OCR Processing
↓
Extract Medicine Information
↓
Show Verification Screen
↓
User edits/confirm details
↓
Generate Medication Timeline
↓
Show dosage + frequency + exact suggested timings + duration + food instruction
↓
Language selector changes English/Hindi/Marathi
↓
Optional Read Aloud button

26. SIH DEMO REQUIREMENT

The final application should be impressive in a 2–3 minute hackathon demonstration.

The demo should clearly show:

Problem:
Handwritten prescriptions can be difficult to understand.

Solution:
Aushadhi Saathi scans and simplifies the prescription.

Technology:
OCR + structured extraction + multilingual UI + medication scheduling.

Impact:
Patients and caregivers can understand WHAT medicine to take, HOW MUCH, HOW OFTEN, WHEN, and FOR HOW LONG.

Prioritize reliability and a polished user experience over adding more features.

Build the complete MVP now with reusable components and clean code.
Do not leave placeholder screens for the main workflow.
If an external OCR API cannot be configured automatically, implement a clean OCR service abstraction plus the fully functional Demo Prescription workflow so the application can still be demonstrated end-to-end.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/562368b1-d1b0-4abc-8cb3-911ab1d7d43c).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
