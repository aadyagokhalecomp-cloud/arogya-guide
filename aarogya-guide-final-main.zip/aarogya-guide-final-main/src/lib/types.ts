export type Medicine = {
  id: string;
  medicineName: string;
  strength: string;
  dosage: string;
  dosageUnit: DosageUnit;
  frequency: FrequencyKey;
  frequencyCount: number;
  suggestedTimings: string[]; // "HH:MM"
  foodInstruction: FoodKey;
  duration: string; // e.g. "5 days"
  specialInstruction: string;
  confidence: number; // 0..1
};

export type DosageUnit = "tablet" | "capsule" | "ml" | "drop" | "sachet" | "unit";

export type FrequencyKey =
  | "once_daily"
  | "twice_daily"
  | "thrice_daily"
  | "four_times_daily"
  | "at_bedtime"
  | "as_needed"
  | "immediately"
  | "once_weekly";

export type FoodKey = "after_food" | "before_food" | "with_food" | "no_instruction";

export type SlotKey = "morning" | "afternoon" | "evening" | "night" | "bedtime";
