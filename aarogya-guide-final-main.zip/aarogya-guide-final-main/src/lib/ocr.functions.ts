import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

/**
 * Prescription reading service.
 *
 * Primary provider: Lovable AI Gateway vision model (server-side only).
 * Optional override: a custom OCR endpoint via OCR_API_URL / OCR_API_KEY.
 *
 * The model is asked to transcribe each prescribed medicine onto one plain
 * line so the existing parser can turn it into structured data. It must never
 * invent medicines it cannot read.
 */
export type OcrResult = {
  configured: boolean;
  ok: boolean;
  text: string;
  error?: string;
};

const PROMPT = `You are reading a photo of a doctor's handwritten or printed prescription.
Transcribe ONLY the prescribed medicines. Output one medicine per line, plain text, no bullets, no numbering, no extra commentary.

Use this line format (omit any part that is genuinely not written):
<Medicine name> <strength e.g. 500 mg> - <dose e.g. 1 tablet> - <frequency abbreviation OD/BD/TDS/QID/HS/SOS/STAT or a dosing pattern like 1-0-1> - <after food|before food|with food> - <duration e.g. 5 days>

Rules:
- Never invent a medicine, strength, dose, frequency or duration. If something is unreadable, leave that part out.
- Keep medicine names in their medical/brand form, in English letters.
- If no medicine can be read at all, output exactly: NO_MEDICINES`;

async function readWithLovableAI(imageBase64: string, mimeType: string): Promise<OcrResult> {
  const key = process.env["LOVABLE_API_KEY"];
  if (!key) return { configured: false, ok: false, text: "" };

  try {
    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({
        model: "google/gemini-3.7-flash",
        messages: [
          {
            role: "user",
            content: [
              { type: "text", text: PROMPT },
              {
                type: "image_url",
                image_url: { url: `data:${mimeType};base64,${imageBase64}` },
              },
            ],
          },
        ],
      }),
    });

    if (!res.ok) {
      const body = await res.text();
      return {
        configured: true,
        ok: false,
        text: "",
        error: `ai_error_${res.status}: ${body.slice(0, 200)}`,
      };
    }

    const json = (await res.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    const text = (json.choices?.[0]?.message?.content ?? "").trim();
    if (!text || text.includes("NO_MEDICINES")) {
      return { configured: true, ok: false, text: "", error: "empty_result" };
    }
    return { configured: true, ok: true, text };
  } catch (err) {
    return {
      configured: true,
      ok: false,
      text: "",
      error: err instanceof Error ? err.message : "unknown_error",
    };
  }
}

export const runOcr = createServerFn({ method: "POST" })
  .inputValidator((data) =>
    z
      .object({
        imageBase64: z.string().min(10),
        mimeType: z.string().min(3),
      })
      .parse(data),
  )
  .handler(async ({ data }): Promise<OcrResult> => {
    const url = process.env["OCR_API_URL"];
    const key = process.env["OCR_API_KEY"];

    // Custom provider takes precedence when configured.
    if (url && key) {
      try {
        const res = await fetch(url, {
          method: "POST",
          headers: {
            "content-type": "application/json",
            authorization: `Bearer ${key}`,
          },
          body: JSON.stringify({ image: data.imageBase64, mimeType: data.mimeType }),
        });
        if (res.ok) {
          const json = (await res.json()) as { text?: string; ParsedText?: string };
          const text = (json.text ?? json.ParsedText ?? "").trim();
          if (text) return { configured: true, ok: true, text };
        }
      } catch {
        // fall through to the built-in reader
      }
    }

    return readWithLovableAI(data.imageBase64, data.mimeType);
  });
