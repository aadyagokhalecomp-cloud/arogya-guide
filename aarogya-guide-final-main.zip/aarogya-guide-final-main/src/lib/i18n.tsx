import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { FoodKey, FrequencyKey, Medicine, SlotKey } from "./types";
import { formatTime12h } from "./medication";

export type Lang = "en" | "hi" | "mr";

export const LANGS: { code: Lang; label: string; speech: string }[] = [
  { code: "en", label: "English", speech: "en-IN" },
  { code: "hi", label: "हिंदी", speech: "hi-IN" },
  { code: "mr", label: "मराठी", speech: "mr-IN" },
];

type Dict = Record<string, string>;

const en: Dict = {
  appName: "Aarogya Guide",
  tagline: "Your Prescription. Simplified.",
  heroText:
    "Scan your handwritten prescription and understand your medicines, dosage and timings in English, Hindi or Marathi.",
  scanPrescription: "Scan Prescription",
  howItWorks: "How It Works",
  home: "Home",
  medicationSchedule: "Medication Schedule",
  step1Title: "Scan",
  step1Text: "Upload or capture a photo of the handwritten prescription.",
  step2Title: "Understand",
  step2Text: "OCR identifies medicine names, dosage, frequency, duration and instructions.",
  step3Title: "Follow",
  step3Text: "Aarogya Guide converts the prescription into an easy medication schedule.",
  uploadTitle: "Upload your prescription",
  uploadHint: "Drag and drop an image here, or choose a file (JPG, JPEG, PNG)",
  chooseFile: "Choose Image",
  useCamera: "Use Camera",
  removeImage: "Remove Image",
  changeImage: "Change Image",
  analyze: "Analyze Prescription",
  tryDemo: "Try Demo Prescription",
  demoBadge: "Demo Prescription",
  privacy: "Your prescription is used only to extract medication information for this session.",
  loading1: "Scanning prescription...",
  loading2: "Reading handwritten medicines...",
  loading3: "Preparing your medication schedule...",
  verifyTitle: "Please verify your prescription details",
  verifySub: "Handwritten prescriptions can be misread. Check every field before continuing.",
  medicine: "Medicine",
  strength: "Strength",
  dosage: "Dosage",
  frequency: "Frequency",
  timing: "Timing",
  food: "Food",
  duration: "Duration",
  special: "Special instruction",
  confirm: "Confirm & Create Schedule",
  editDetails: "Edit Details",
  doneEditing: "Done Editing",
  addMedicine: "Add Medicine",
  remove: "Remove",
  needsVerification: "Needs verification",
  lowConfidence: "Unable to confidently read this medicine name.",
  pleaseVerify: "Please verify",
  yourSchedule: "Your Medication Schedule",
  greeting: "Good morning! Here is your medication plan.",
  today: "Today",
  medicinesCount: "Medicines",
  morningDoses: "Morning doses",
  afternoonDoses: "Afternoon doses",
  eveningDoses: "Evening doses",
  nightDoses: "Night doses",
  readAloud: "Read Aloud",
  stopReading: "Stop",
  speechUnavailable: "Text-to-speech is not available in this browser.",
  timingNote:
    "Suggested timings are generated from the prescribed frequency. Follow the doctor's instructions if specific timings are written on the prescription.",
  disclaimer:
    "Aarogya Guide helps simplify prescription information. It does not diagnose medical conditions or replace advice from a doctor or pharmacist. Always verify extracted information before taking medicine.",
  noSchedule: "No medication schedule yet.",
  noScheduleText: "Scan a prescription or try the demo prescription to see your schedule.",
  errNoImage: "Please upload a prescription image first.",
  errFormat: "Unsupported file. Please upload a JPG, JPEG or PNG image.",
  errOcr:
    "We couldn't clearly read this prescription. Please upload a clearer image or verify the extracted details manually.",
  errNoMedicines: "No medicine information could be read from this image.",
  back: "Back",
  morning: "Morning",
  afternoon: "Afternoon",
  evening: "Evening",
  night: "Night",
  bedtime: "Bedtime",
  once_daily: "Once daily",
  twice_daily: "Twice daily",
  thrice_daily: "Three times daily",
  four_times_daily: "Four times daily",
  at_bedtime: "At bedtime",
  as_needed: "As needed",
  immediately: "Immediately (single dose)",
  once_weekly: "Once weekly",
  after_food: "After food",
  before_food: "Before food",
  with_food: "With food",
  no_instruction: "No food instruction",
  tablet: "tablet",
  capsule: "capsule",
  ml: "ml",
  drop: "drop",
  sachet: "sachet",
  unit: "unit",
  at: "at",
  and: "and",
};

const hi: Dict = {
  appName: "औषधि साथी",
  tagline: "आपका पर्चा। आसान भाषा में।",
  heroText:
    "अपने हाथ से लिखे पर्चे को स्कैन करें और अपनी दवाइयाँ, मात्रा और समय अंग्रेज़ी, हिंदी या मराठी में समझें।",
  scanPrescription: "पर्चा स्कैन करें",
  howItWorks: "यह कैसे काम करता है",
  home: "होम",
  medicationSchedule: "दवा समय-सारणी",
  step1Title: "स्कैन करें",
  step1Text: "हाथ से लिखे पर्चे की फोटो अपलोड करें या कैमरे से लें।",
  step2Title: "समझें",
  step2Text: "OCR दवा का नाम, मात्रा, आवृत्ति, अवधि और निर्देश पहचानता है।",
  step3Title: "पालन करें",
  step3Text: "औषधि साथी पर्चे को आसान दवा समय-सारणी में बदल देता है।",
  uploadTitle: "अपना पर्चा अपलोड करें",
  uploadHint: "यहाँ इमेज खींचकर छोड़ें, या फ़ाइल चुनें (JPG, JPEG, PNG)",
  chooseFile: "इमेज चुनें",
  useCamera: "कैमरा उपयोग करें",
  removeImage: "इमेज हटाएँ",
  changeImage: "इमेज बदलें",
  analyze: "पर्चे का विश्लेषण करें",
  tryDemo: "डेमो पर्चा देखें",
  demoBadge: "डेमो पर्चा",
  privacy: "आपका पर्चा केवल इसी सत्र में दवा जानकारी निकालने के लिए उपयोग होता है।",
  loading1: "पर्चा स्कैन हो रहा है...",
  loading2: "हाथ से लिखी दवाइयाँ पढ़ी जा रही हैं...",
  loading3: "आपकी दवा समय-सारणी तैयार हो रही है...",
  verifyTitle: "कृपया अपने पर्चे की जानकारी जाँचें",
  verifySub: "हाथ से लिखे पर्चे गलत पढ़े जा सकते हैं। आगे बढ़ने से पहले हर जानकारी जाँच लें।",
  medicine: "दवा",
  strength: "मात्रा (स्ट्रेंथ)",
  dosage: "खुराक",
  frequency: "कितनी बार",
  timing: "समय",
  food: "भोजन",
  duration: "अवधि",
  special: "विशेष निर्देश",
  confirm: "पुष्टि करें और सारणी बनाएँ",
  editDetails: "जानकारी बदलें",
  doneEditing: "बदलाव पूरा",
  addMedicine: "दवा जोड़ें",
  remove: "हटाएँ",
  needsVerification: "जाँच आवश्यक",
  lowConfidence: "इस दवा का नाम स्पष्ट रूप से नहीं पढ़ा जा सका।",
  pleaseVerify: "कृपया जाँचें",
  yourSchedule: "आपकी दवा समय-सारणी",
  greeting: "नमस्ते! यह आपकी दवा योजना है।",
  today: "आज",
  medicinesCount: "दवाइयाँ",
  morningDoses: "सुबह की खुराक",
  afternoonDoses: "दोपहर की खुराक",
  eveningDoses: "शाम की खुराक",
  nightDoses: "रात की खुराक",
  readAloud: "सुनें",
  stopReading: "रोकें",
  speechUnavailable: "इस ब्राउज़र में आवाज़ सुविधा उपलब्ध नहीं है।",
  timingNote:
    "सुझाए गए समय निर्धारित आवृत्ति से बनाए गए हैं। यदि पर्चे पर समय लिखा है तो डॉक्टर के निर्देश का पालन करें।",
  disclaimer:
    "औषधि साथी पर्चे की जानकारी को आसान बनाता है। यह बीमारी की पहचान नहीं करता और डॉक्टर या फार्मासिस्ट की सलाह का विकल्प नहीं है। दवा लेने से पहले जानकारी अवश्य जाँचें।",
  noSchedule: "अभी कोई दवा समय-सारणी नहीं है।",
  noScheduleText: "पर्चा स्कैन करें या डेमो पर्चा देखें।",
  errNoImage: "कृपया पहले पर्चे की इमेज अपलोड करें।",
  errFormat: "यह फ़ाइल समर्थित नहीं है। कृपया JPG, JPEG या PNG इमेज अपलोड करें।",
  errOcr:
    "हम इस पर्चे को स्पष्ट रूप से नहीं पढ़ पाए। कृपया साफ़ इमेज अपलोड करें या जानकारी स्वयं जाँचें।",
  errNoMedicines: "इस इमेज से कोई दवा जानकारी नहीं पढ़ी जा सकी।",
  back: "वापस",
  morning: "सुबह",
  afternoon: "दोपहर",
  evening: "शाम",
  night: "रात",
  bedtime: "सोते समय",
  once_daily: "दिन में 1 बार",
  twice_daily: "दिन में 2 बार",
  thrice_daily: "दिन में 3 बार",
  four_times_daily: "दिन में 4 बार",
  at_bedtime: "सोते समय",
  as_needed: "ज़रूरत पड़ने पर",
  immediately: "तुरंत (एक बार)",
  once_weekly: "सप्ताह में 1 बार",
  after_food: "भोजन के बाद",
  before_food: "भोजन से पहले",
  with_food: "भोजन के साथ",
  no_instruction: "कोई भोजन निर्देश नहीं",
  tablet: "गोली",
  capsule: "कैप्सूल",
  ml: "मि.ली.",
  drop: "बूँद",
  sachet: "पुड़िया",
  unit: "यूनिट",
  at: "बजे",
  and: "और",
};

const mr: Dict = {
  appName: "औषधी साथी",
  tagline: "तुमची चिठ्ठी. सोप्या भाषेत.",
  heroText:
    "तुमची हस्तलिखित औषधचिठ्ठी स्कॅन करा आणि औषधे, मात्रा व वेळा इंग्रजी, हिंदी किंवा मराठीत समजून घ्या.",
  scanPrescription: "चिठ्ठी स्कॅन करा",
  howItWorks: "हे कसे चालते",
  home: "मुख्यपृष्ठ",
  medicationSchedule: "औषध वेळापत्रक",
  step1Title: "स्कॅन करा",
  step1Text: "हस्तलिखित चिठ्ठीचा फोटो अपलोड करा किंवा कॅमेऱ्याने काढा.",
  step2Title: "समजून घ्या",
  step2Text: "OCR औषधाचे नाव, मात्रा, वारंवारता, कालावधी व सूचना ओळखतो.",
  step3Title: "पालन करा",
  step3Text: "औषधी साथी चिठ्ठीचे सोपे औषध वेळापत्रक तयार करते.",
  uploadTitle: "तुमची चिठ्ठी अपलोड करा",
  uploadHint: "इथे इमेज ड्रॅग करा, किंवा फाइल निवडा (JPG, JPEG, PNG)",
  chooseFile: "इमेज निवडा",
  useCamera: "कॅमेरा वापरा",
  removeImage: "इमेज काढा",
  changeImage: "इमेज बदला",
  analyze: "चिठ्ठीचे विश्लेषण करा",
  tryDemo: "डेमो चिठ्ठी पहा",
  demoBadge: "डेमो चिठ्ठी",
  privacy: "तुमची चिठ्ठी फक्त याच सत्रात औषध माहिती काढण्यासाठी वापरली जाते.",
  loading1: "चिठ्ठी स्कॅन होत आहे...",
  loading2: "हस्तलिखित औषधे वाचली जात आहेत...",
  loading3: "तुमचे औषध वेळापत्रक तयार होत आहे...",
  verifyTitle: "कृपया तुमच्या चिठ्ठीची माहिती तपासा",
  verifySub: "हस्तलिखित चिठ्ठी चुकीची वाचली जाऊ शकते. पुढे जाण्याआधी प्रत्येक माहिती तपासा.",
  medicine: "औषध",
  strength: "स्ट्रेंथ",
  dosage: "मात्रा",
  frequency: "किती वेळा",
  timing: "वेळ",
  food: "जेवण",
  duration: "कालावधी",
  special: "विशेष सूचना",
  confirm: "निश्चित करा आणि वेळापत्रक बनवा",
  editDetails: "माहिती बदला",
  doneEditing: "बदल पूर्ण",
  addMedicine: "औषध जोडा",
  remove: "काढा",
  needsVerification: "तपासणी आवश्यक",
  lowConfidence: "या औषधाचे नाव स्पष्टपणे वाचता आले नाही.",
  pleaseVerify: "कृपया तपासा",
  yourSchedule: "तुमचे औषध वेळापत्रक",
  greeting: "नमस्कार! हे तुमचे औषध नियोजन आहे.",
  today: "आज",
  medicinesCount: "औषधे",
  morningDoses: "सकाळचे डोस",
  afternoonDoses: "दुपारचे डोस",
  eveningDoses: "संध्याकाळचे डोस",
  nightDoses: "रात्रीचे डोस",
  readAloud: "ऐका",
  stopReading: "थांबा",
  speechUnavailable: "या ब्राउझरमध्ये आवाज सुविधा उपलब्ध नाही.",
  timingNote:
    "सुचवलेल्या वेळा ठरवलेल्या वारंवारतेवरून तयार केल्या आहेत. चिठ्ठीवर वेळ लिहिली असल्यास डॉक्टरांच्या सूचनांचे पालन करा.",
  disclaimer:
    "औषधी साथी चिठ्ठीची माहिती सोपी करते. ते आजाराचे निदान करत नाही आणि डॉक्टर किंवा फार्मासिस्टच्या सल्ल्याला पर्याय नाही. औषध घेण्यापूर्वी माहिती नक्की तपासा.",
  noSchedule: "अजून औषध वेळापत्रक नाही.",
  noScheduleText: "चिठ्ठी स्कॅन करा किंवा डेमो चिठ्ठी पहा.",
  errNoImage: "कृपया आधी चिठ्ठीची इमेज अपलोड करा.",
  errFormat: "ही फाइल समर्थित नाही. कृपया JPG, JPEG किंवा PNG इमेज अपलोड करा.",
  errOcr:
    "आम्हाला ही चिठ्ठी स्पष्टपणे वाचता आली नाही. कृपया स्पष्ट इमेज अपलोड करा किंवा माहिती स्वतः तपासा.",
  errNoMedicines: "या इमेजमधून औषधाची माहिती वाचता आली नाही.",
  back: "मागे",
  morning: "सकाळी",
  afternoon: "दुपारी",
  evening: "संध्याकाळी",
  night: "रात्री",
  bedtime: "झोपताना",
  once_daily: "दिवसातून 1 वेळा",
  twice_daily: "दिवसातून 2 वेळा",
  thrice_daily: "दिवसातून 3 वेळा",
  four_times_daily: "दिवसातून 4 वेळा",
  at_bedtime: "झोपताना",
  as_needed: "गरज असेल तेव्हा",
  immediately: "लगेच (एकदाच)",
  once_weekly: "आठवड्यातून 1 वेळा",
  after_food: "जेवणानंतर",
  before_food: "जेवणापूर्वी",
  with_food: "जेवणासोबत",
  no_instruction: "जेवणाची सूचना नाही",
  tablet: "गोळी",
  capsule: "कॅप्सूल",
  ml: "मि.ली.",
  drop: "थेंब",
  sachet: "पुडी",
  unit: "युनिट",
  at: "वाजता",
  and: "आणि",
};

const DICTS: Record<Lang, Dict> = { en, hi, mr };

type Ctx = {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (key: string) => string;
};

const LanguageContext = createContext<Ctx | null>(null);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("en");

  useEffect(() => {
    const stored = typeof window !== "undefined" ? window.localStorage.getItem("as-lang") : null;
    if (stored === "en" || stored === "hi" || stored === "mr") setLangState(stored);
  }, []);

  const setLang = useCallback((l: Lang) => {
    setLangState(l);
    try {
      window.localStorage.setItem("as-lang", l);
    } catch {
      /* ignore */
    }
  }, []);

  const t = useCallback((key: string) => DICTS[lang][key] ?? en[key] ?? key, [lang]);

  const value = useMemo(() => ({ lang, setLang, t }), [lang, setLang, t]);
  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLang() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error("useLang must be used within LanguageProvider");
  return ctx;
}

/** Localised time, e.g. "8:00 AM" / "सुबह 8:00 बजे" */
export function localTime(time: string, lang: Lang, t: (k: string) => string) {
  const slotKey = slotOf(time);
  if (lang === "en") return `${t(slotKey)} — ${formatTime12h(time)}`;
  const [h12, mm] = formatTime12h(time).split(" ")[0]?.split(":") ?? ["", ""];
  return `${t(slotKey)} ${h12}:${mm} ${t("at")}`;
}

function slotOf(time: string): SlotKey {
  const h = Number(time.split(":")[0] ?? 0);
  if (h < 12) return "morning";
  if (h < 17) return "afternoon";
  if (h < 21) return "evening";
  return "night";
}

export function localFrequency(f: FrequencyKey, t: (k: string) => string) {
  return t(f);
}

export function localFood(f: FoodKey, t: (k: string) => string) {
  return t(f);
}

export function localDosage(m: Medicine, t: (k: string) => string) {
  return `${m.dosage || "?"} ${t(m.dosageUnit)}`;
}

export function localDuration(duration: string, t: (k: string) => string, lang: Lang) {
  if (lang === "en" || !duration) return duration;
  const match = duration.match(/(\d+)\s*(day|week|month)/i);
  if (!match) return duration;
  const n = match[1];
  const unit = (match[2] ?? "").toLowerCase();
  const words: Record<string, Record<Lang, string>> = {
    day: { en: "days", hi: "दिन", mr: "दिवस" },
    week: { en: "weeks", hi: "सप्ताह", mr: "आठवडे" },
    month: { en: "months", hi: "महीने", mr: "महिने" },
  };
  return `${n} ${words[unit]?.[lang] ?? unit}`;
}

/** Sentence used by Read Aloud. */
export function speakSentence(m: Medicine, lang: Lang, t: (k: string) => string) {
  const times = m.suggestedTimings.map((x) => localTime(x, lang, t)).join(` ${t("and")} `);
  const name = `${m.medicineName} ${m.strength}`.trim();
  if (lang === "hi")
    return `${name}. ${localDosage(m, t)}, ${t(m.frequency)}, ${t(m.foodInstruction)}. ${times}.`;
  if (lang === "mr")
    return `${name}. ${localDosage(m, t)}, ${t(m.frequency)}, ${t(m.foodInstruction)}. ${times}.`;
  return `${name}. Take ${localDosage(m, t)} ${t(m.frequency).toLowerCase()}, ${t(m.foodInstruction).toLowerCase()}. ${times}.`;
}
