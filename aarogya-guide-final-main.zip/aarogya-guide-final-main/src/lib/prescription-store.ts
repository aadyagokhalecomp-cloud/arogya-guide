import { useSyncExternalStore } from "react";
import type { Medicine } from "./types";

type State = {
  medicines: Medicine[];
  isDemo: boolean;
  confirmed: boolean;
};

const KEY = "aarogya-guide-session";

let state: State = { medicines: [], isDemo: false, confirmed: false };
let hydrated = false;
const listeners = new Set<() => void>();

function hydrate() {
  if (hydrated || typeof window === "undefined") return;
  hydrated = true;
  try {
    const raw = window.sessionStorage.getItem(KEY);
    if (raw) state = { ...state, ...(JSON.parse(raw) as State) };
  } catch {
    /* ignore */
  }
}

function persist() {
  try {
    window.sessionStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    /* ignore */
  }
}

function emit() {
  listeners.forEach((l) => l());
}

export function setPrescription(medicines: Medicine[], isDemo: boolean) {
  state = { medicines, isDemo, confirmed: false };
  persist();
  emit();
}

export function updateMedicine(id: string, patch: Partial<Medicine>) {
  state = {
    ...state,
    medicines: state.medicines.map((m) => (m.id === id ? { ...m, ...patch } : m)),
  };
  persist();
  emit();
}

export function removeMedicine(id: string) {
  state = { ...state, medicines: state.medicines.filter((m) => m.id !== id) };
  persist();
  emit();
}

export function addMedicine(m: Medicine) {
  state = { ...state, medicines: [...state.medicines, m] };
  persist();
  emit();
}

export function setConfirmed(confirmed: boolean) {
  state = { ...state, confirmed };
  persist();
  emit();
}

export function clearPrescription() {
  state = { medicines: [], isDemo: false, confirmed: false };
  persist();
  emit();
}

const EMPTY: State = { medicines: [], isDemo: false, confirmed: false };

export function usePrescription(): State {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    () => {
      hydrate();
      return state;
    },
    () => EMPTY,
  );
}
