import type { DosageUnit, FoodKey, FrequencyKey, Medicine, SlotKey } from "./types";

export const SLOT_TIMES: Record<SlotKey, string> = {
  morning: "08:00",
  afternoon: "14:00",
  evening: "20:00",
  night: "22:00",
  bedtime: "22:00",
};

export const FREQUENCY_TIMINGS: Record<FrequencyKey, string[]> = {
  once_daily: ["08:00"],
  twice_daily: ["08:00", "20:00"],
  thrice_daily: ["08:00", "14:00", "20:00"],
  four_times_daily: ["08:00", "12:00", "16:00", "20:00"],
  at_bedtime: ["22:00"],
  as_needed: [],
  immediately: [],
  once_weekly: ["08:00"],
};

export const FREQUENCY_COUNT: Record<FrequencyKey, number> = {
  once_daily: 1,
  twice_daily: 2,
  thrice_daily: 3,
  four_times_daily: 4,
  at_bedtime: 1,
  as_needed: 0,
  immediately: 1,
  once_weekly: 1,
};

/** Common prescription abbreviations -> internal frequency key. */
export const FREQUENCY_ABBREVIATIONS: Record<string, FrequencyKey> = {
  OD: "once_daily",
  QD: "once_daily",
  BD: "twice_daily",
  BID: "twice_daily",
  TDS: "thrice_daily",
  TID: "thrice_daily",
  QID: "four_times_daily",
  QDS: "four_times_daily",
  HS: "at_bedtime",
  SOS: "as_needed",
  PRN: "as_needed",
  STAT: "immediately",
};

export const FOOD_ABBREVIATIONS: Record<string, FoodKey> = {
  AC: "before_food",
  PC: "after_food",
};

export function timeToSlot(time: string): SlotKey {
  const h = Number(time.split(":")[0] ?? 0);
  if (h < 12) return "morning";
  if (h < 17) return "afternoon";
  if (h < 21) return "evening";
  return "bedtime";
}

export function formatTime12h(time: string): string {
  const parts = time.split(":");
  const h = Number(parts[0] ?? 0);
  const m = Number(parts[1] ?? 0);
  const suffix = h >= 12 ? "PM" : "AM";
  const hour = h % 12 === 0 ? 12 : h % 12;
  return `${hour}:${String(m).padStart(2, "0")} ${suffix}`;
}

const uid = () => Math.random().toString(36).slice(2, 10);

/**
 * Parses one raw OCR line into a structured medicine.
 * Anything that cannot be read confidently is left empty and flagged for
 * verification — never guessed.
 */
export function parsePrescriptionLine(line: string): Medicine | null {
  const raw = line.trim();
  if (!raw || raw.length < 3) return null;

  let confidence = 0.9;

  // Strength e.g. 500 mg / 10mg / 5 ml
  const strengthMatch = raw.match(/(\d+(?:\.\d+)?)\s?(mg|mcg|ml|g|iu)\b/i);
  const strength = strengthMatch ? `${strengthMatch[1]} ${(strengthMatch[2] ?? "").toLowerCase()}` : "";

  // Medicine name: leading word(s) before strength / dash / dosage
  const namePart = raw.split(/[-–—]/)[0] ?? raw;
  const medicineName = namePart
    .replace(/(\d+(?:\.\d+)?)\s?(mg|mcg|ml|g|iu)\b/i, "")
    .replace(/[^A-Za-z0-9 +/]/g, " ")
    .trim();
  if (!medicineName || medicineName.length < 3) confidence = Math.min(confidence, 0.4);

  // Frequency abbreviation or words
  let frequency: FrequencyKey | null = null;
  const upper = ` ${raw.toUpperCase()} `;
  for (const abbr of Object.keys(FREQUENCY_ABBREVIATIONS)) {
    if (new RegExp(`[^A-Z]${abbr}[^A-Z]`).test(upper)) {
      frequency = FREQUENCY_ABBREVIATIONS[abbr] ?? null;
      break;
    }
  }
  if (!frequency) {
    if (/once\s*a?\s*week|weekly/i.test(raw)) frequency = "once_weekly";
    else if (/thrice|three\s*times/i.test(raw)) frequency = "thrice_daily";
    else if (/four\s*times/i.test(raw)) frequency = "four_times_daily";
    else if (/twice/i.test(raw)) frequency = "twice_daily";
    else if (/once\s*daily|once\s*a\s*day/i.test(raw)) frequency = "once_daily";
    else if (/bed\s*time|night/i.test(raw)) frequency = "at_bedtime";
  }
  if (!frequency) {
    // Frequency written as 1-0-1 pattern
    const pattern = raw.match(/\b([01])\s*-\s*([01])\s*-\s*([01])\b/);
    if (pattern) {
      const count = [pattern[1], pattern[2], pattern[3]].filter((v) => v === "1").length;
      frequency =
        count === 3 ? "thrice_daily" : count === 2 ? "twice_daily" : "once_daily";
    }
  }
  if (!frequency) confidence = Math.min(confidence, 0.45);

  // Dosage: "1 tab", "2 tablets", "5 ml"
  const dosageMatch = raw.match(/\b(\d+(?:\.\d+)?)\s*(tab|tabs|tablet|tablets|cap|caps|capsule|capsules|ml|drop|drops|sachet)\b/i);
  let dosage = dosageMatch ? (dosageMatch[1] ?? "") : "";
  let dosageUnit: DosageUnit = "tablet";
  if (dosageMatch) {
    const u = (dosageMatch[2] ?? "").toLowerCase();
    dosageUnit = u.startsWith("cap")
      ? "capsule"
      : u === "ml"
        ? "ml"
        : u.startsWith("drop")
          ? "drop"
          : u === "sachet"
            ? "sachet"
            : "tablet";
  } else {
    dosage = "";
    confidence = Math.min(confidence, 0.5);
  }

  // Food instruction
  let foodInstruction: FoodKey = "no_instruction";
  if (/after\s*(food|meal)|\bPC\b/i.test(raw)) foodInstruction = "after_food";
  else if (/before\s*(food|meal)|empty\s*stomach|\bAC\b/i.test(raw)) foodInstruction = "before_food";
  else if (/with\s*(food|meal)/i.test(raw)) foodInstruction = "with_food";

  // Duration
  const durationMatch = raw.match(/\b(\d+)\s*(day|days|week|weeks|month|months)\b/i);
  const duration = durationMatch
    ? `${durationMatch[1]} ${(durationMatch[2] ?? "").toLowerCase().replace(/s$/, "")}${Number(durationMatch[1]) > 1 ? "s" : ""}`
    : "";
  if (!duration) confidence = Math.min(confidence, 0.6);

  const freq: FrequencyKey = frequency ?? "once_daily";

  return {
    id: uid(),
    medicineName,
    strength,
    dosage,
    dosageUnit,
    frequency: freq,
    frequencyCount: FREQUENCY_COUNT[freq],
    suggestedTimings: FREQUENCY_TIMINGS[freq],
    foodInstruction,
    duration,
    specialInstruction: "",
    confidence,
  };
}

export function parsePrescriptionText(text: string): Medicine[] {
  return text
    .split(/\r?\n/)
    .map((l) =>
      l
        .replace(/\*\*/g, "")
        .replace(/^\s*(?:[-*•]|\d+[.)])\s*/, "")
        .trim(),
    )
    .filter((l) => l.length > 2 && !/^(here is|here are|transcription|rx\b|no_medicines)/i.test(l))
    .map((l) => parsePrescriptionLine(l))
    .filter((m): m is Medicine => m !== null);
}


export function needsVerification(m: Medicine): boolean {
  return m.confidence < 0.7 || !m.medicineName || !m.dosage;
}

export function emptyMedicine(): Medicine {
  return {
    id: uid(),
    medicineName: "",
    strength: "",
    dosage: "1",
    dosageUnit: "tablet",
    frequency: "once_daily",
    frequencyCount: 1,
    suggestedTimings: FREQUENCY_TIMINGS.once_daily,
    foodInstruction: "after_food",
    duration: "",
    specialInstruction: "",
    confidence: 1,
  };
}

export const DEMO_MEDICINES: Medicine[] = [
  {
    id: "demo-1",
    medicineName: "Paracetamol",
    strength: "500 mg",
    dosage: "1",
    dosageUnit: "tablet",
    frequency: "twice_daily",
    frequencyCount: 2,
    suggestedTimings: ["08:00", "20:00"],
    foodInstruction: "after_food",
    duration: "5 days",
    specialInstruction: "",
    confidence: 0.95,
  },
  {
    id: "demo-2",
    medicineName: "Cetirizine",
    strength: "10 mg",
    dosage: "1",
    dosageUnit: "tablet",
    frequency: "at_bedtime",
    frequencyCount: 1,
    suggestedTimings: ["22:00"],
    foodInstruction: "after_food",
    duration: "5 days",
    specialInstruction: "",
    confidence: 0.88,
  },
  {
    id: "demo-3",
    medicineName: "Vitamin D3",
    strength: "60000 IU",
    dosage: "1",
    dosageUnit: "capsule",
    frequency: "once_weekly",
    frequencyCount: 1,
    suggestedTimings: ["08:00"],
    foodInstruction: "after_food",
    duration: "4 weeks",
    specialInstruction: "Sunday after breakfast",
    confidence: 0.62,
  },
];

export function groupBySlot(medicines: Medicine[]) {
  const order: SlotKey[] = ["morning", "afternoon", "evening", "bedtime"];
  return order
    .map((slot) => ({
      slot,
      time: SLOT_TIMES[slot],
      items: medicines.filter((m) => m.suggestedTimings.some((t) => timeToSlot(t) === slot)),
    }))
    .filter((g) => g.items.length > 0);
}
