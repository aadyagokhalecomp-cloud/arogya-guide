import { Link } from "@tanstack/react-router";
import { HeartPulse } from "lucide-react";
import { LANGS, useLang } from "@/lib/i18n";
import { cn } from "@/lib/utils";

export function SiteHeader() {
  const { lang, setLang, t } = useLang();

  const navLinkClass = "rounded-full px-3 py-2 text-sm font-medium text-foreground/70 transition-colors hover:bg-accent hover:text-accent-foreground";
  const activeProps = { className: cn(navLinkClass, "bg-accent text-accent-foreground") };

  return (
    <header className="sticky top-0 z-40 border-b border-border/70 bg-background/85 backdrop-blur">
      <div className="mx-auto grid max-w-6xl grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-4 py-3 sm:flex sm:justify-between">
        <Link to="/" className="flex min-w-0 items-center gap-2">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-primary text-primary-foreground shadow-soft">
            <HeartPulse className="h-5 w-5" />
          </span>
          <span className="truncate text-lg font-bold tracking-tight text-foreground sm:text-xl">
            {t("appName")}
          </span>
        </Link>

        <nav className="col-span-2 flex flex-wrap items-center gap-1 sm:col-auto">
          <Link to="/" className={navLinkClass} activeOptions={{ exact: true }} activeProps={activeProps}>
            {t("home")}
          </Link>
          <Link to="/scan" className={navLinkClass} activeProps={activeProps}>
            {t("scanPrescription")}
          </Link>
          <Link to="/schedule" className={navLinkClass} activeProps={activeProps}>
            {t("medicationSchedule")}
          </Link>
        </nav>

        <div
          className="col-span-2 flex shrink-0 items-center gap-1 rounded-full border border-border bg-card p-1 sm:col-auto"
          role="group"
          aria-label="Language"
        >
          {LANGS.map((l) => (
            <button
              key={l.code}
              type="button"
              onClick={() => setLang(l.code)}
              aria-pressed={lang === l.code}
              className={cn(
                "rounded-full px-3 py-1.5 text-sm font-semibold transition-colors",
                lang === l.code
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground",
              )}
            >
              {l.label}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
}
