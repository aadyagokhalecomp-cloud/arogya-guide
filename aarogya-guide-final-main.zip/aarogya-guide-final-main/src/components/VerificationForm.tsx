import { AlertTriangle, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { DosageUnit, FoodKey, FrequencyKey, Medicine } from "@/lib/types";
import { FREQUENCY_COUNT, FREQUENCY_TIMINGS, emptyMedicine, needsVerification } from "@/lib/medication";
import { addMedicine, removeMedicine, updateMedicine } from "@/lib/prescription-store";
import { localTime, useLang } from "@/lib/i18n";

const FREQUENCIES: FrequencyKey[] = [
  "once_daily",
  "twice_daily",
  "thrice_daily",
  "four_times_daily",
  "at_bedtime",
  "as_needed",
  "immediately",
  "once_weekly",
];

const FOODS: FoodKey[] = ["after_food", "before_food", "with_food", "no_instruction"];
const UNITS: DosageUnit[] = ["tablet", "capsule", "ml", "drop", "sachet", "unit"];

export function VerificationForm({ medicines }: { medicines: Medicine[] }) {
  const { t, lang } = useLang();

  return (
    <div className="space-y-5">
      {medicines.map((m, i) => (
        <div key={m.id} className="rounded-3xl border border-border bg-card p-5 shadow-soft">
          <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3">
            <h3 className="truncate text-base font-bold text-foreground">
              {t("medicine")} {i + 1}
            </h3>
            <Button
              variant="ghost"
              size="sm"
              className="shrink-0 text-destructive hover:text-destructive"
              onClick={() => removeMedicine(m.id)}
            >
              <Trash2 /> {t("remove")}
            </Button>
          </div>

          {needsVerification(m) ? (
            <p className="mt-3 flex items-start gap-2 rounded-2xl bg-warning-soft px-3 py-2 text-sm font-medium text-foreground/80">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-warning" />
              {t("pleaseVerify")} — {t("lowConfidence")}
            </p>
          ) : null}

          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor={`name-${m.id}`}>{t("medicine")}</Label>
              <Input
                id={`name-${m.id}`}
                value={m.medicineName}
                onChange={(e) => updateMedicine(m.id, { medicineName: e.target.value, confidence: 1 })}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor={`strength-${m.id}`}>{t("strength")}</Label>
              <Input
                id={`strength-${m.id}`}
                value={m.strength}
                placeholder="500 mg"
                onChange={(e) => updateMedicine(m.id, { strength: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor={`dosage-${m.id}`}>{t("dosage")}</Label>
              <div className="flex gap-2">
                <Input
                  id={`dosage-${m.id}`}
                  className="w-20"
                  value={m.dosage}
                  onChange={(e) => updateMedicine(m.id, { dosage: e.target.value, confidence: 1 })}
                />
                <Select
                  value={m.dosageUnit}
                  onValueChange={(v) => updateMedicine(m.id, { dosageUnit: v as DosageUnit })}
                >
                  <SelectTrigger className="flex-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {UNITS.map((u) => (
                      <SelectItem key={u} value={u}>
                        {t(u)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>{t("frequency")}</Label>
              <Select
                value={m.frequency}
                onValueChange={(v) => {
                  const f = v as FrequencyKey;
                  updateMedicine(m.id, {
                    frequency: f,
                    frequencyCount: FREQUENCY_COUNT[f],
                    suggestedTimings: FREQUENCY_TIMINGS[f],
                  });
                }}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {FREQUENCIES.map((f) => (
                    <SelectItem key={f} value={f}>
                      {t(f)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>{t("food")}</Label>
              <Select
                value={m.foodInstruction}
                onValueChange={(v) => updateMedicine(m.id, { foodInstruction: v as FoodKey })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {FOODS.map((f) => (
                    <SelectItem key={f} value={f}>
                      {t(f)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor={`duration-${m.id}`}>{t("duration")}</Label>
              <Input
                id={`duration-${m.id}`}
                value={m.duration}
                placeholder="5 days"
                onChange={(e) => updateMedicine(m.id, { duration: e.target.value })}
              />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor={`special-${m.id}`}>{t("special")}</Label>
              <Input
                id={`special-${m.id}`}
                value={m.specialInstruction}
                onChange={(e) => updateMedicine(m.id, { specialInstruction: e.target.value })}
              />
            </div>
          </div>

          <p className="mt-4 rounded-2xl bg-muted px-3 py-2 text-sm text-muted-foreground">
            {t("timing")}:{" "}
            <span className="font-semibold text-foreground">
              {m.suggestedTimings.length
                ? m.suggestedTimings.map((x) => localTime(x, lang, t)).join(" • ")
                : "—"}
            </span>
          </p>
        </div>
      ))}

      <Button variant="outline" size="lg" onClick={() => addMedicine(emptyMedicine())}>
        <Plus /> {t("addMedicine")}
      </Button>
    </div>
  );
}
