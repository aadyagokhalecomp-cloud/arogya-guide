import { AlertTriangle, CalendarDays, Clock, Pill, Repeat, Utensils } from "lucide-react";
import type { Medicine } from "@/lib/types";
import { localDosage, localDuration, localTime, useLang } from "@/lib/i18n";
import { needsVerification } from "@/lib/medication";

function Row({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
}) {
  return (
    <div className="flex min-w-0 items-start gap-2">
      <span className="mt-0.5 shrink-0 text-primary">{icon}</span>
      <span className="min-w-0">
        <span className="block text-xs font-medium uppercase tracking-wide text-muted-foreground">
          {label}
        </span>
        <span className="block text-base font-semibold text-foreground">{value || "—"}</span>
      </span>
    </div>
  );
}

export function MedicineCard({ medicine }: { medicine: Medicine }) {
  const { t, lang } = useLang();
  const flagged = needsVerification(medicine);

  return (
    <article className="rounded-3xl border border-border bg-card p-5 shadow-soft transition-shadow hover:shadow-lifted">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
        <div className="min-w-0">
          <h3 className="truncate text-xl font-bold text-foreground">
            {medicine.medicineName || t("pleaseVerify")}
          </h3>
          {medicine.strength ? (
            <p className="text-sm font-medium text-primary">{medicine.strength}</p>
          ) : null}
        </div>
        <span className="shrink-0 rounded-2xl bg-primary-soft p-2 text-primary">
          <Pill className="h-5 w-5" />
        </span>
      </div>

      {flagged ? (
        <p className="mt-3 flex items-start gap-2 rounded-2xl bg-warning-soft px-3 py-2 text-sm font-medium text-foreground/80">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-warning" />
          {t("needsVerification")}
        </p>
      ) : null}

      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <Row icon={<Pill className="h-4 w-4" />} label={t("dosage")} value={localDosage(medicine, t)} />
        <Row icon={<Repeat className="h-4 w-4" />} label={t("frequency")} value={t(medicine.frequency)} />
        <Row
          icon={<Clock className="h-4 w-4" />}
          label={t("timing")}
          value={medicine.suggestedTimings.map((x) => localTime(x, lang, t)).join(" • ")}
        />
        <Row
          icon={<Utensils className="h-4 w-4" />}
          label={t("food")}
          value={t(medicine.foodInstruction)}
        />
        <Row
          icon={<CalendarDays className="h-4 w-4" />}
          label={t("duration")}
          value={localDuration(medicine.duration, t, lang)}
        />
        {medicine.specialInstruction ? (
          <Row
            icon={<AlertTriangle className="h-4 w-4" />}
            label={t("special")}
            value={medicine.specialInstruction}
          />
        ) : null}
      </div>
    </article>
  );
}
