import { useEffect, useState } from "react";
import { Volume2, VolumeX } from "lucide-react";
import { Button } from "@/components/ui/button";
import { LANGS, speakSentence, useLang } from "@/lib/i18n";
import type { Medicine } from "@/lib/types";

export function ReadAloudButton({ medicines }: { medicines: Medicine[] }) {
  const { lang, t } = useLang();
  const [supported, setSupported] = useState(false);
  const [speaking, setSpeaking] = useState(false);

  useEffect(() => {
    setSupported(typeof window !== "undefined" && "speechSynthesis" in window);
    return () => {
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  if (!supported) {
    return (
      <Button variant="outline" size="lg" disabled title={t("speechUnavailable")}>
        <VolumeX /> {t("readAloud")}
      </Button>
    );
  }

  const speak = () => {
    const synth = window.speechSynthesis;
    if (speaking) {
      synth.cancel();
      setSpeaking(false);
      return;
    }
    const localeTag = LANGS.find((l) => l.code === lang)?.speech ?? "en-IN";
    const voices = synth.getVoices();
    const voice =
      voices.find((v) => v.lang.replace("_", "-") === localeTag) ??
      voices.find((v) => v.lang.startsWith(lang)) ??
      null;

    synth.cancel();
    medicines.forEach((m) => {
      const utter = new SpeechSynthesisUtterance(speakSentence(m, lang, t));
      utter.lang = voice?.lang ?? localeTag;
      if (voice) utter.voice = voice;
      utter.rate = 0.9;
      synth.speak(utter);
    });
    setSpeaking(true);
    const poll = window.setInterval(() => {
      if (!synth.speaking) {
        setSpeaking(false);
        window.clearInterval(poll);
      }
    }, 500);
  };

  return (
    <Button variant="outline" size="lg" onClick={speak}>
      {speaking ? <VolumeX /> : <Volume2 />}
      {speaking ? t("stopReading") : t("readAloud")}
    </Button>
  );
}
