import { ShieldAlert } from "lucide-react";
import { useLang } from "@/lib/i18n";

export function SafetyNotice() {
  const { t } = useLang();
  return (
    <div className="flex items-start gap-3 rounded-2xl border border-warning/40 bg-warning-soft px-4 py-3 text-sm leading-relaxed text-foreground/80">
      <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-warning" />
      <p>{t("disclaimer")}</p>
    </div>
  );
}
