import { CloudSun, Info, Moon, Sunrise, Sunset } from "lucide-react";
import type { Medicine } from "@/lib/types";
import { groupBySlot, formatTime12h, SLOT_TIMES } from "@/lib/medication";
import { useLang } from "@/lib/i18n";
import { MedicineCard } from "./MedicineCard";

const SLOT_ICON = {
  morning: Sunrise,
  afternoon: CloudSun,
  evening: Sunset,
  bedtime: Moon,
} as const;

export function MedicationTimeline({ medicines }: { medicines: Medicine[] }) {
  const { t } = useLang();
  const groups = groupBySlot(medicines);

  return (
    <div className="space-y-8">
      {groups.map((group) => {
        const Icon = SLOT_ICON[group.slot as keyof typeof SLOT_ICON] ?? Sunrise;
        return (
        <section key={group.slot} className="animate-in fade-in slide-in-from-bottom-2 duration-500">
          <div className="grid grid-cols-[auto_minmax(0,1fr)] items-center gap-3">
            <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-primary-soft text-primary">
              <Icon className="h-6 w-6" />
            </span>
            <div className="min-w-0">
              <h3 className="truncate text-xl font-bold text-foreground">
                {t(group.slot === "bedtime" ? "bedtime" : group.slot)}
              </h3>
              <p className="text-sm font-medium text-muted-foreground">
                {formatTime12h(SLOT_TIMES[group.slot])}
              </p>
            </div>
          </div>

          <div className="mt-4 grid gap-4 border-l-2 border-dashed border-border pl-4 sm:pl-6 lg:grid-cols-2">
            {group.items.map((m) => (
              <MedicineCard key={`${group.slot}-${m.id}`} medicine={m} />
            ))}
          </div>
        </section>
        );
      })}

      <p className="flex items-start gap-2 rounded-2xl bg-muted px-4 py-3 text-sm text-muted-foreground">
        <Info className="mt-0.5 h-4 w-4 shrink-0" />
        {t("timingNote")}
      </p>
    </div>
  );
}
