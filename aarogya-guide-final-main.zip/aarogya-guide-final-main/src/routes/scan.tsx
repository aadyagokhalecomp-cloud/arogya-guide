import { useCallback, useEffect, useRef, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import {
  AlertTriangle,
  Camera,
  CheckCircle2,
  ImageUp,
  Lock,
  Pencil,
  ScanLine,
  Sparkles,
  Trash2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { SafetyNotice } from "@/components/SafetyNotice";
import { VerificationForm } from "@/components/VerificationForm";
import { useLang } from "@/lib/i18n";
import { DEMO_MEDICINES, parsePrescriptionText } from "@/lib/medication";
import { setConfirmed, setPrescription, usePrescription } from "@/lib/prescription-store";
import { runOcr } from "@/lib/ocr.functions";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/scan")({
  head: () => ({
    meta: [
      { title: "Scan Prescription — Aarogya Guide" },
      {
        name: "description",
        content:
          "Upload or capture a handwritten prescription and let Aarogya Guide extract medicines, dosage, frequency and timings.",
      },
      { property: "og:title", content: "Scan Prescription — Aarogya Guide" },
      {
        property: "og:description",
        content: "Turn a handwritten prescription photo into a clear medication schedule.",
      },
    ],
  }),
  component: ScanPage,
});

const ACCEPTED = ["image/jpeg", "image/jpg", "image/png"];

type Stage = "upload" | "processing" | "verify";

function ScanPage() {
  const { t } = useLang();
  const navigate = useNavigate();
  const { medicines } = usePrescription();

  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [stage, setStage] = useState<Stage>("upload");
  const [step, setStep] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [demo, setDemo] = useState(false);

  const fileInput = useRef<HTMLInputElement>(null);
  const cameraInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!file) {
      setPreview(null);
      return;
    }
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const pick = useCallback(
    (f: File | undefined | null) => {
      setError(null);
      if (!f) return;
      if (!ACCEPTED.includes(f.type)) {
        setError(t("errFormat"));
        return;
      }
      setFile(f);
    },
    [t],
  );

  const readAsBase64 = (f: File) =>
    new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = String(reader.result);
        resolve(result.split(",")[1] ?? "");
      };
      reader.onerror = () => reject(new Error("read_failed"));
      reader.readAsDataURL(f);
    });

  const runStages = async (work: () => Promise<void>) => {
    setStage("processing");
    setStep(0);
    const timer1 = window.setTimeout(() => setStep(1), 900);
    const timer2 = window.setTimeout(() => setStep(2), 1900);
    try {
      await work();
    } finally {
      window.clearTimeout(timer1);
      window.clearTimeout(timer2);
    }
  };

  const analyze = async () => {
    if (!file) {
      setError(t("errNoImage"));
      return;
    }
    setError(null);
    setDemo(false);
    await runStages(async () => {
      try {
        const imageBase64 = await readAsBase64(file);
        const result = await runOcr({ data: { imageBase64, mimeType: file.type } });
        await new Promise((r) => setTimeout(r, 2400));

        if (!result.configured || !result.ok) {
          setStage("upload");
          setError(t("errOcr"));
          return;
        }
        const parsed = parsePrescriptionText(result.text);
        if (parsed.length === 0) {
          setStage("upload");
          setError(t("errNoMedicines"));
          return;
        }
        setPrescription(parsed, false);
        setStage("verify");
      } catch {
        setStage("upload");
        setError(t("errOcr"));
      }
    });
  };

  const loadDemo = async () => {
    setError(null);
    setDemo(true);
    await runStages(async () => {
      await new Promise((r) => setTimeout(r, 2400));
      setPrescription(
        DEMO_MEDICINES.map((m) => ({ ...m })),
        true,
      );
      setStage("verify");
    });
  };

  const confirm = () => {
    setConfirmed(true);
    navigate({ to: "/schedule" });
  };

  const loadingLabels = [t("loading1"), t("loading2"), t("loading3")];

  return (
    <div className="mx-auto max-w-3xl space-y-8 px-4 py-10">
      <header>
        <h1 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
          {t("scanPrescription")}
        </h1>
        <p className="mt-2 text-muted-foreground">{t("uploadTitle")}</p>
      </header>

      {stage === "upload" ? (
        <div className="space-y-6">
          {error ? (
            <p className="flex items-start gap-2 rounded-2xl border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm font-medium text-destructive">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              {error}
            </p>
          ) : null}

          {preview ? (
            <div className="overflow-hidden rounded-3xl border border-border bg-card shadow-soft">
              <img
                src={preview}
                alt="Prescription preview"
                className="max-h-[420px] w-full object-contain bg-muted"
              />
              <div className="flex flex-wrap gap-2 p-4">
                <Button variant="outline" onClick={() => fileInput.current?.click()}>
                  <ImageUp /> {t("changeImage")}
                </Button>
                <Button variant="ghost" className="text-destructive" onClick={() => setFile(null)}>
                  <Trash2 /> {t("removeImage")}
                </Button>
              </div>
            </div>
          ) : (
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragOver(false);
                pick(e.dataTransfer.files?.[0]);
              }}
              className={cn(
                "rounded-3xl border-2 border-dashed bg-card p-8 text-center transition-colors sm:p-12",
                dragOver ? "border-primary bg-primary-soft" : "border-border",
              )}
            >
              <span className="mx-auto grid h-16 w-16 place-items-center rounded-3xl bg-primary-soft text-primary">
                <ImageUp className="h-8 w-8" />
              </span>
              <p className="mt-4 text-lg font-semibold text-foreground">{t("uploadTitle")}</p>
              <p className="mt-1 text-sm text-muted-foreground">{t("uploadHint")}</p>
              <div className="mt-6 flex flex-wrap justify-center gap-3">
                <Button size="lg" onClick={() => fileInput.current?.click()}>
                  <ImageUp /> {t("chooseFile")}
                </Button>
                <Button size="lg" variant="outline" onClick={() => cameraInput.current?.click()}>
                  <Camera /> {t("useCamera")}
                </Button>
              </div>
            </div>
          )}

          <input
            ref={fileInput}
            type="file"
            accept="image/jpeg,image/jpg,image/png"
            className="hidden"
            onChange={(e) => pick(e.target.files?.[0])}
          />
          <input
            ref={cameraInput}
            type="file"
            accept="image/*"
            capture="environment"
            className="hidden"
            onChange={(e) => pick(e.target.files?.[0])}
          />

          <div className="flex flex-col gap-3 sm:flex-row">
            <Button size="lg" className="flex-1" onClick={analyze} disabled={!file}>
              <ScanLine /> {t("analyze")}
            </Button>
            <Button size="lg" variant="secondary" className="flex-1" onClick={loadDemo}>
              <Sparkles /> {t("tryDemo")}
            </Button>
          </div>

          <p className="flex items-start gap-2 text-sm text-muted-foreground">
            <Lock className="mt-0.5 h-4 w-4 shrink-0" />
            {t("privacy")}
          </p>

          <SafetyNotice />
        </div>
      ) : null}

      {stage === "processing" ? (
        <div className="rounded-3xl border border-border bg-card p-8 text-center shadow-soft">
          <span className="mx-auto grid h-16 w-16 animate-pulse place-items-center rounded-3xl bg-primary-soft text-primary">
            <ScanLine className="h-8 w-8" />
          </span>
          <p className="mt-5 text-lg font-semibold text-foreground">{loadingLabels[step]}</p>
          <Progress value={(step + 1) * 33.3} className="mx-auto mt-5 max-w-md" />
        </div>
      ) : null}

      {stage === "verify" ? (
        <div className="space-y-6">
          {demo ? (
            <span className="inline-block rounded-full bg-accent px-3 py-1 text-xs font-bold uppercase tracking-wide text-accent-foreground">
              {t("demoBadge")}
            </span>
          ) : null}
          <div>
            <h2 className="text-2xl font-bold text-foreground">{t("verifyTitle")}</h2>
            <p className="mt-1 text-muted-foreground">{t("verifySub")}</p>
          </div>

          <VerificationForm medicines={medicines} />

          <div className="flex flex-col gap-3 sm:flex-row">
            <Button size="lg" className="flex-1" onClick={confirm} disabled={medicines.length === 0}>
              <CheckCircle2 /> {t("confirm")}
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="flex-1"
              onClick={() => setStage("upload")}
            >
              <Pencil /> {t("back")}
            </Button>
          </div>

          <SafetyNotice />
        </div>
      ) : null}
    </div>
  );
}
