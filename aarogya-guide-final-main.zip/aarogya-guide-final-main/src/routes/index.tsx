import { createFileRoute, Link } from "@tanstack/react-router";
import { BookOpenCheck, CalendarClock, ScanLine, Languages, Volume2, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SafetyNotice } from "@/components/SafetyNotice";
import { useLang } from "@/lib/i18n";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Aarogya Guide — Your Prescription. Simplified." },
      {
        name: "description",
        content:
          "Scan a handwritten prescription and understand your medicines, dosage and timings in English, Hindi or Marathi.",
      },
      { property: "og:title", content: "Aarogya Guide — Your Prescription. Simplified." },
      {
        property: "og:description",
        content:
          "A multilingual medication assistant that turns handwritten prescriptions into a clear medication schedule.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  const { t } = useLang();

  const steps = [
    { icon: ScanLine, title: t("step1Title"), text: t("step1Text") },
    { icon: BookOpenCheck, title: t("step2Title"), text: t("step2Text") },
    { icon: CalendarClock, title: t("step3Title"), text: t("step3Text") },
  ];

  const highlights = [
    { icon: Languages, text: "English • हिंदी • मराठी" },
    { icon: Volume2, text: t("readAloud") },
    { icon: ShieldCheck, text: t("pleaseVerify") },
  ];

  return (
    <div>
      <section className="bg-hero">
        <div className="mx-auto max-w-5xl px-4 py-16 text-center sm:py-24">
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-1.5 text-sm font-semibold text-primary shadow-soft">
            <Languages className="h-4 w-4" /> English • हिंदी • मराठी
          </span>
          <h1 className="mt-6 text-4xl font-black tracking-tight text-foreground sm:text-6xl">
            {t("appName")}
          </h1>
          <p className="mt-3 text-xl font-semibold text-primary sm:text-2xl">{t("tagline")}</p>
          <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground sm:text-lg">
            {t("heroText")}
          </p>
          <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
            <Button asChild size="xl">
              <Link to="/scan">
                <ScanLine /> {t("scanPrescription")}
              </Link>
            </Button>
            <Button asChild size="xl" variant="outline">
              <a href="#how-it-works">{t("howItWorks")}</a>
            </Button>
          </div>

          <ul className="mx-auto mt-10 flex max-w-2xl flex-wrap justify-center gap-3">
            {highlights.map((h) => (
              <li
                key={h.text}
                className="flex items-center gap-2 rounded-2xl border border-border bg-card px-4 py-2 text-sm font-medium text-foreground/80 shadow-soft"
              >
                <h.icon className="h-4 w-4 text-primary" /> {h.text}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section id="how-it-works" className="mx-auto max-w-5xl px-4 py-16">
        <h2 className="text-center text-3xl font-bold tracking-tight text-foreground">
          {t("howItWorks")}
        </h2>
        <div className="mt-10 grid gap-5 md:grid-cols-3">
          {steps.map((s, i) => (
            <div
              key={s.title}
              className="rounded-3xl border border-border bg-card p-6 shadow-soft transition-shadow hover:shadow-lifted"
            >
              <div className="flex items-center gap-3">
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-primary-soft text-primary">
                  <s.icon className="h-6 w-6" />
                </span>
                <span className="text-sm font-bold uppercase tracking-wide text-muted-foreground">
                  {i + 1}
                </span>
              </div>
              <h3 className="mt-4 text-xl font-bold text-foreground">{s.title}</h3>
              <p className="mt-2 leading-relaxed text-muted-foreground">{s.text}</p>
            </div>
          ))}
        </div>

        <div className="mt-12">
          <SafetyNotice />
        </div>
      </section>
    </div>
  );
}
