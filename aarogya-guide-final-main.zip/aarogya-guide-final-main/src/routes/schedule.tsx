import { createFileRoute, Link } from "@tanstack/react-router";
import { CalendarCheck, ScanLine } from "lucide-react";
import { Button } from "@/components/ui/button";
import { MedicationTimeline } from "@/components/MedicationTimeline";
import { ReadAloudButton } from "@/components/ReadAloudButton";
import { SafetyNotice } from "@/components/SafetyNotice";
import { usePrescription } from "@/lib/prescription-store";
import { timeToSlot } from "@/lib/medication";
import { useLang } from "@/lib/i18n";

export const Route = createFileRoute("/schedule")({
  head: () => ({
    meta: [
      { title: "Medication Schedule — Aarogya Guide" },
      {
        name: "description",
        content:
          "See your daily medication timeline with dosage, frequency, timings, food instructions and duration in English, Hindi or Marathi.",
      },
      { property: "og:title", content: "Medication Schedule — Aarogya Guide" },
      {
        property: "og:description",
        content: "A simple daily medication timeline built from your prescription.",
      },
    ],
  }),
  component: SchedulePage,
});

function SchedulePage() {
  const { t } = useLang();
  const { medicines, isDemo } = usePrescription();

  if (medicines.length === 0) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 text-center">
        <span className="mx-auto grid h-16 w-16 place-items-center rounded-3xl bg-primary-soft text-primary">
          <CalendarCheck className="h-8 w-8" />
        </span>
        <h1 className="mt-5 text-2xl font-bold text-foreground">{t("noSchedule")}</h1>
        <p className="mt-2 text-muted-foreground">{t("noScheduleText")}</p>
        <Button asChild size="lg" className="mt-6">
          <Link to="/scan">
            <ScanLine /> {t("scanPrescription")}
          </Link>
        </Button>
      </div>
    );
  }

  const countBySlot = (slot: string) =>
    medicines.reduce(
      (acc, m) => acc + m.suggestedTimings.filter((x) => timeToSlot(x) === slot).length,
      0,
    );

  const summary = [
    { label: t("medicinesCount"), value: medicines.length },
    { label: t("morningDoses"), value: countBySlot("morning") },
    { label: t("afternoonDoses"), value: countBySlot("afternoon") },
    { label: t("eveningDoses"), value: countBySlot("evening") },
    { label: t("nightDoses"), value: countBySlot("bedtime") },
  ].filter((s) => s.value > 0);

  return (
    <div className="mx-auto max-w-5xl space-y-8 px-4 py-10">
      <header className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-4 sm:flex sm:items-center sm:justify-between">
        <div className="min-w-0">
          {isDemo ? (
            <span className="inline-block rounded-full bg-accent px-3 py-1 text-xs font-bold uppercase tracking-wide text-accent-foreground">
              {t("demoBadge")}
            </span>
          ) : null}
          <h1 className="mt-2 text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            {t("yourSchedule")}
          </h1>
          <p className="mt-1 text-muted-foreground">{t("greeting")}</p>
        </div>
        <ReadAloudButton medicines={medicines} />
      </header>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {summary.map((s) => (
          <div key={s.label} className="rounded-2xl border border-border bg-card p-4 shadow-soft">
            <p className="text-2xl font-bold text-primary">{s.value}</p>
            <p className="text-sm text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>

      <div>
        <h2 className="mb-4 text-lg font-bold uppercase tracking-wide text-muted-foreground">
          {t("today")}
        </h2>
        <MedicationTimeline medicines={medicines} />
      </div>

      <SafetyNotice />
    </div>
  );
}
